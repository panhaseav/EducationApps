package com.example.loginregister

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class C_company : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.c_company)
    }
}