package com.example.loginregister

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class D_company : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.d_company)
    }
}