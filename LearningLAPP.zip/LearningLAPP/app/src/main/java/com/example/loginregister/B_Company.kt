package com.example.loginregister

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class B_Company : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.b_company)
    }
}